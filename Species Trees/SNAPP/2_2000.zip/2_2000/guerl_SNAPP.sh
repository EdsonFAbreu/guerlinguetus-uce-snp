#!/bin/bash
#SBATCH --job-name guerl_SNAPP
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/SNAPP/2_2000/

module load beast2

/temporario/apps/gnu/beast2/bin/beast -threads 16 snapp_red_2_2000.xml


