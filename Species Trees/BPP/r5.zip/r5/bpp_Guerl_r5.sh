#!/bin/bash
#SBATCH --job-name bpp_sp_tree_500loci_r5
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --time=180:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/BPP/Species_tree_A01/500loci/Refazer/r5

./bpp --cfile guerl-A01.ctl
