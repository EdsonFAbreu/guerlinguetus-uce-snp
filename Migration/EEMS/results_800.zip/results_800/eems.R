###################################################################################################################################################
#library(devtools)
#install_github("thierrygosselin/radiator")
#install.packages("SeqArray")
#devtools::package_info(pkgs = "SeqArray") # to verify version
#BiocManager::install("SeqArray")

#install.packages("RStoolbox")
#library(devtools)
#install_github("bleutner/RStoolbox")

#devtools::install_github("dipetkov/eems/plotting/rEEMSplots")

library("adegenet")
library("radiator")
library("rEEMSplots")
library("rworldmap")
library("rworldxtra")
library("maptools")
library("rgdal")
library("RColorBrewer")
library("raster")
library("tidyverse")
#library("RStoolbox")
library(vcfR)

###################################################################################################################################################

#Lam_tan_genind<-read.structure("~/Downloads/Varzeas/EEMS/Lam_tan/Lampropsar_snp_nomissing.str",n.ind = 16,n.loc = 1937,col.lab = 1,col.pop = 2,row.marknames = 0,col.others=0,onerowperind=FALSE,ask = FALSE)
vcfR <- read.vcfR("gue_final_snps.vcf")
gue_genind<-vcfR2genind(vcfR)
gue_genind

rownames(gue_genind@tab)<-sub('.{2}$', '',rownames(gue_genind@tab))
pop(gue_genind)<- rownames(gue_genind@tab)
#gue_genind@pop
gue.genpop <- genind2genpop(gue_genind)

gue.dist <- dist.genpop(gue.genpop, method = 4, diag = TRUE, upper = TRUE)
gue.dist_matrix <- as.matrix(gue.dist)
write.table(gue.dist_matrix, file = 'gue_snps.diffs',sep = " ",row.names = FALSE,col.names = FALSE)


###para gerar o .coord e o .outer nao deixar linhas em branco no final
#Para extrair os pontos do poligono de distribuicao usando o R
shape <- readOGR("poli.shp")
gue_snps.outer <- as.data.frame(shape@polygons[[1]]@Polygons[[1]]@coords)
gue_snps.outer_LAT_LONG <- data.frame(gue_snps.outer$V2, gue_snps.outer$V1)

write.table(gue_snps.outer_LAT_LONG, file = 'gue_snps.outer', col.names = F, row.names = F)

# Rodar comando no terminal

# Voltar pro R

mcmcpath = "~/Desktop/eems_input/guerlinguetus/results_800"
plotpath = "~/Desktop/eems_input/guerlinguetus/results_800/plots"

riverss <- readOGR("/Users/edson/Dropbox/Não compartilhado/Qgis files/ne_10m_rivers_lake_centerlines/ne_10m_rivers_lake_centerlines.shp")
map_SA<-readOGR("/Users/edson/Dropbox/Não compartilhado/Qgis files/South_America/SouthAmerica.shp")
map_SA <- as(map_SA, 'SpatialLinesDataFrame')

eems.plots(mcmcpath,plotpath,longlat = FALSE, add.demes = TRUE,projection.in = "+proj=longlat +datum=WGS84",add.outline = T,
           col.outline = "gray50", plot.width = 9,lwd.map = 1,out.png=FALSE,
           m.plot.xy = {lines(map_SA,col="black");lines(riverss,col="gray70")},
           q.plot.xy = {lines(map_SA,col="black");lines(riverss,col="gray70")})




projection_none <- "+proj=longlat +datum=WGS84"
projection_mercator <- "+proj=merc +datum=WGS84"

eemsResults <- rEEMSplots::eems.plots(mcmcpath, plotpath, longlat = T,out.png = FALSE, projection.in = projection_none, projection.out = projection_mercator)
