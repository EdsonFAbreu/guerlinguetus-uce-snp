x <- list.files(pattern="*treeout")
for(a in 1:length(x)) {
  if (a==1) {
    output <- scan(x[a], what="character")[1]
  } else {
    output <- c(output, scan(x[a], what="character")[1])
  }
}
write(output, file="final.100.bootstraps.trees", ncolumns=1)
