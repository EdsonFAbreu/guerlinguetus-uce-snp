str <- read.structure('project_data.str', n.ind = 64, n.loc = 1169, col.lab = 1, col.pop = 2, onerowperind = TRUE, 
                      row.marknames = 0, NA.char= 0, ask = FALSE)

gen_dist<-as.dist(mat_gen_dist(str, dist = "basic", null_val = FALSE))

### Geographic data #####
coord <- read.csv("coord_ind.csv", header = T)
mDIST <- earth.dist(coord[,2:3], dist = TRUE)
mDIST <- as.dist(mDIST)
mDIST_vec <- as.vector(mDIST)
hist(mDIST_vec)

mantel_total <- mantel.rtest(gen_dist, mDIST, 10000)

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.7473636 

#Based on 10000 replicates
#Simulated p-value: 9.999e-05 
#Alternative hypothesis: greater 

#Std.Obs  Expectation     Variance 
#2.664678e+01 4.664339e-05 7.865389e-04

plot.new()
tiff("mantel_total.tiff", width=50, height=40, unit="cm", res=300)
par(mar=c(5,5,1,1))
plot(mDIST, gen_dist, pch = 16,  ylab = "Genetic Distance", xlab = "Geographic Distance", cex = 1.5, cex.lab=1.5, axes= T) 
abline(lm(gen_dist  ~ mDIST), col = "gray30", lwd = 3)
legend('topleft', legend = "r = 0.74, p=value = 0.000", bty = 'n', cex = 2)
dev.off()

setwd('..') #move directory backward



####### amazonia ######
str_amazonia <- read.structure('amazonia.str', n.ind = 37, n.loc = 1169, col.lab = 1, col.pop = 2, onerowperind = TRUE, 
                           row.marknames = 0, NA.char= 0, ask = FALSE)

gen_dist_am<-as.dist(mat_gen_dist(str_amazonia, dist = "basic", null_val = FALSE))

### Geographic data #####
mDIST_am <- as.dist(earth.dist(coord[1:37,2:3], dist = TRUE))

mantel_am <- mantel.rtest(gen_dist_am, mDIST_am, 10000)

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.4372931 

#Based on 10000 replicates
#Simulated p-value: 9.999e-05 
#Alternative hypothesis: greater 

#Std.Obs  Expectation     Variance 
#5.6626965213 0.0002844229 0.0059557089 

plot.new()
tiff("mantel_amazonia.tiff", width=50, height=40, unit="cm", res=300)
par(mar=c(5,5,1,1))
plot(mDIST_am, gen_dist_am, pch = 16,  ylab = "Genetic Distance", xlab = "Geographic Distance", cex = 1.5, cex.lab=1.5, axes= T) 
abline(lm(gen_dist_am  ~ mDIST_am), col = "gray30", lwd = 3)
legend('topleft', legend = "r = 0.43, p=value = 0.000", bty = 'n', cex = 2)
dev.off()

setwd('..') #move directory backward

####### Pop 3 ########
str_pop3 <- read.structure('Pop3.str', n.ind = 15, n.loc = 1169, col.lab = 1, col.pop = 2, onerowperind = TRUE, 
                      row.marknames = 0, NA.char= 0, ask = FALSE)

gen_dist_pop3<-as.dist(mat_gen_dist(str_pop3, dist = "basic", null_val = FALSE))

### Geographic data #####
mDIST_pop3 <- as.dist(earth.dist(coord[6:20,2:3], dist = TRUE))

mantel_pop3 <- mantel.rtest(gen_dist_pop3, mDIST_pop3, 10000)

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.6508561 

#Based on 10000 replicates
#Simulated p-value: 9.999e-05 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#3.92437592  0.00142683  0.02738561 

plot.new()
tiff("mantel_pop3.tiff", width=50, height=40, unit="cm", res=300)
par(mar=c(5,5,1,1))
plot(mDIST_pop3, gen_dist_pop3, pch = 16,  ylab = "Genetic Distance", xlab = "Geographic Distance", cex = 1.5, cex.lab=1.5, axes= T) 
abline(lm(gen_dist_pop3  ~ mDIST_pop3), col = "gray30", lwd = 3)
legend('topleft', legend = "r = 0.65, p=value = 0.000", bty = 'n', cex = 2)
dev.off()

setwd('..') #move directory backward


####### Pop 4 ########
str_pop4 <- read.structure('Pop4.str', n.ind = 10, n.loc = 1169, col.lab = 1, col.pop = 2, onerowperind = TRUE, 
                           row.marknames = 0, NA.char= 0, ask = FALSE)

gen_dist_pop4<-as.dist(mat_gen_dist(str_pop4, dist = "basic", null_val = FALSE))

### Geographic data #####
mDIST_pop4 <- as.dist(earth.dist(coord[21:30,2:3], dist = TRUE))

mantel_pop4 <- mantel.rtest(gen_dist_pop4, mDIST_pop4, 10000)

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.3155652 

#Based on 10000 replicates
#Simulated p-value: 0.05249475 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#1.717844372 0.001298381 0.033467982 


plot.new()
tiff("mantel_pop4.tiff", width=50, height=40, unit="cm", res=300)
par(mar=c(5,5,1,1))
plot(mDIST_pop4, gen_dist_pop4, pch = 16,  ylab = "Genetic Distance", xlab = "Geographic Distance", cex = 1.5, cex.lab=1.5, axes= T) 
abline(lm(gen_dist_pop4  ~ mDIST_pop4), col = "gray30", lwd = 3)
legend('topleft', legend = "r = 0.31, p=value = 0.052", bty = 'n', cex = 2)
dev.off()

setwd('..') #move directory backward

####### Pop 6 ########
str_pop6 <- read.structure('Pop6.str', n.ind = 27, n.loc = 1169, col.lab = 1, col.pop = 2, onerowperind = TRUE, 
                           row.marknames = 0, NA.char= 0, ask = FALSE)

gen_dist_pop6<-as.dist(mat_gen_dist(str_pop6, dist = "basic", null_val = FALSE))

### Geographic data #####
mDIST_pop6 <- as.dist(earth.dist(coord[38:64,2:3], dist = TRUE))

mantel_pop6 <- mantel.rtest(gen_dist_pop6, mDIST_pop6, 10000)

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.477318 

#Based on 10000 replicates
#Simulated p-value: 9.999e-05 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#4.216492976 0.001064853 0.012757715 

plot.new()
tiff("mantel_pop6.tiff", width=50, height=40, unit="cm", res=300)
par(mar=c(5,5,1,1))
plot(mDIST_pop6, gen_dist_pop6, pch = 16,  ylab = "Genetic Distance", xlab = "Geographic Distance", cex = 1.5, cex.lab=1.5, axes= T) 
abline(lm(gen_dist_pop6  ~ mDIST_pop6), col = "gray30", lwd = 3)
legend('topleft', legend = "r = 0.47, p=value = 0.000", bty = 'n', cex = 2)
dev.off()

setwd('..') #move directory backward