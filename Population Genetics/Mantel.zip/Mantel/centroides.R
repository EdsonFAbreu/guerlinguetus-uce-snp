coord <- read.csv("coord_ind.csv", header = T)

pop1<-coord[1:2, 2:3]
geosphere::centroid(pop1)

pop2<-coord[3:5, 2:3]
geosphere::centroid(pop2)

pop3<-coord[6:20, 2:3]
geosphere::centroid(pop3)

pop4<-coord[21:30, 2:3]
geosphere::centroid(pop4)

pop5<-coord[31:37, 2:3]
geosphere::centroid(pop5)

pop6<-coord[38:64, 2:3]
geosphere::centroid(pop6)




  
