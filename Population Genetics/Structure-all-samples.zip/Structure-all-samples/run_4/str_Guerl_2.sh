#!/bin/bash
#SBATCH --job-name Guerl_K6,7,8,9,10_rep4
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=4
#SBATCH --cpus-per-task=1
#SBATCH --time=150:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/Structure/run_4

./structure -m ./mainparams -K 6 -o Guerl_k6-rep4.txt > Guerl_k6-rep4.log
./structure -m ./mainparams -K 7 -o Guerl_k7-rep4.txt > Guerl_k7-rep4.log
./structure -m ./mainparams -K 8 -o Guerl_k8-rep4.txt > Guerl_k8-rep4.log
./structure -m ./mainparams -K 9 -o Guerl_k9-rep4.txt > Guerl_k9-rep4.log
./structure -m ./mainparams -K 10 -o Guerl_k10-rep4.txt > Guerl_k10-rep4.log