#!/bin/bash
#SBATCH --job-name Guerl_K11,12,13,14,15_rep9
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=4
#SBATCH --cpus-per-task=1
#SBATCH --time=150:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/Structure/run_9

./structure -m ./mainparams -K 11 -o Guerl_k11-rep9.txt > Guerl_k11-rep9.log
./structure -m ./mainparams -K 12 -o Guerl_k12-rep9.txt > Guerl_k12-rep9.log
./structure -m ./mainparams -K 13 -o Guerl_k13-rep9.txt > Guerl_k13-rep9.log
./structure -m ./mainparams -K 14 -o Guerl_k14-rep9.txt > Guerl_k14-rep9.log
./structure -m ./mainparams -K 15 -o Guerl_k15-rep9.txt > Guerl_k15-rep9.log