#!/bin/bash
#SBATCH --job-name Guerl_K1,2,3,4,5_rep8
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=4
#SBATCH --cpus-per-task=1
#SBATCH --time=150:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/Structure/run_8

./structure -m ./mainparams -K 1 -o Guerl_k1-rep8.txt > Guerl_k1-rep8.log
./structure -m ./mainparams -K 2 -o Guerl_k2-rep8.txt > Guerl_k2-rep8.log
./structure -m ./mainparams -K 3 -o Guerl_k3-rep8.txt > Guerl_k3-rep8.log
./structure -m ./mainparams -K 4 -o Guerl_k4-rep8.txt > Guerl_k4-rep8.log
./structure -m ./mainparams -K 5 -o Guerl_k5-rep8.txt > Guerl_k5-rep8.log
