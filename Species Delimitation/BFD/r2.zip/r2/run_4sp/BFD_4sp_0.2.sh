#!/bin/bash
#SBATCH --job-name BFD_4sp_0.2
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=1
#SBATCH --mem-per-cpu=16G
#SBATCH --cpus-per-task=1
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


# ----------------Modules------------------------- #
module load beast2
#
# ----------------Your Commands------------------- #
#
 
source ./run${1}.sh

