#!/bin/bash
#SBATCH --job-name BFD_4sp_0.002
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=16
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL

cd /scratch/5150251/Guerlinguetus/BFD/fev_23/run_4sp/0.002

module load beast2

/temporario/apps/gnu/beast2/bin/beast -threads 32 BFD_4sp_0.002_path.xml
