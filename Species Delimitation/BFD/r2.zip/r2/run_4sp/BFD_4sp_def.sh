#!/bin/bash
#SBATCH --job-name BFD_4sp_def
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=16
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL

cd /scratch/5150251/Guerlinguetus/BFD/fev_23/run_4sp/default

module load beast2

/temporario/apps/gnu/beast2/bin/beast -threads 32 BFD_4sp_def_path.xml
