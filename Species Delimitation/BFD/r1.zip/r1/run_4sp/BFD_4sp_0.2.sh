#!/bin/bash
#SBATCH --job-name BFD_4sp_0.2
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


# ----------------Modules------------------------- #
module load beast2
#
# ----------------Your Commands------------------- #
#
echo + `date` job $JOB_NAME started in $QUEUE with jobID=$JOB_ID on $HOSTNAME
echo + NSLOTS = $NSLOTS
 
#
if [ -z $1 ]; then
  echo "Give the run number as an argument: e.g. qsub beast_step_run.job 0"
  exit 1
fi
 
source ./run${1}.sh
#
echo = `date` job $JOB_NAME done
