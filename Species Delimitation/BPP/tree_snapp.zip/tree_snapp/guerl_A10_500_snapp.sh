#!/bin/bash
#SBATCH --job-name guerl_snapp_r1
#SBATCH --mail-user=joyce.prado@usp.br
#SBATCH --ntasks=2
#SBATCH --cpus-per-task=16
#SBATCH --time=190:00:00
#SBATCH --partition=SP2
#SBATCH --mail-type=BEGIN,END,FAIL


cd /scratch/5150251/Guerlinguetus/BPP/Species_Del_A10/500loci/tree_snapp/rep1/

module load bpp

perl BPP_snapp.pl
